package com.spotify.userprofile.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class UserTest {

    private User userUnderTest;

    @BeforeEach
    void setUp() {
        userUnderTest = new User(0, "userName", "email", "password");
    }

    @Test
    void testSetUserName() {
        userUnderTest.setUserName("userName");
    }

    @Test
    void testSetEmail() {

        userUnderTest.setEmail("email");


    }

    @Test
    void testSetPassword() {

        userUnderTest.setPassword("password");
    }

    @Test
    void testGetUserName() {
        assertThat(userUnderTest.getUserName()).isNull();
    }
}