package com.cts.musicapp.model;

import lombok.Data;

@Data
public class Image {
    private String url;
    private Integer height;
    private Integer width;
}
