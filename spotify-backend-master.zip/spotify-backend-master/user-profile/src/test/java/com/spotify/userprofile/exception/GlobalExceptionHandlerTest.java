package com.spotify.userprofile.exception;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

@ContextConfiguration(classes = {GlobalExceptionHandler.class})
@ExtendWith(SpringExtension.class)
class GlobalExceptionHandlerTest {
    @Autowired
    private GlobalExceptionHandler globalExceptionHandler;

    @Test
    void testIncaseOfUserNameIsTaken() {
        ResponseEntity<String> actualIncaseOfUserNameIsTakenResult = globalExceptionHandler
                .incaseOfUserNameIsTaken(new Exception("foo"));
        assertEquals("foo", actualIncaseOfUserNameIsTakenResult.getBody());
        assertEquals(400, actualIncaseOfUserNameIsTakenResult.getStatusCodeValue());
        assertTrue(actualIncaseOfUserNameIsTakenResult.getHeaders().isEmpty());
    }

    @Test
    void testHandleCustomValidationException() {
        ResponseEntity<String> actualHandleCustomValidationExceptionResult = globalExceptionHandler
                .handleCustomValidationException(new CustomValidationException("An error occurred"));
        assertEquals("An error occurred", actualHandleCustomValidationExceptionResult.getBody());
        assertEquals(400, actualHandleCustomValidationExceptionResult.getStatusCodeValue());
        assertTrue(actualHandleCustomValidationExceptionResult.getHeaders().isEmpty());
    }


    @Test
    void testHandleCustomValidationException2() {
        CustomValidationException ex = mock(CustomValidationException.class);
        when(ex.getMessage()).thenReturn("Not all who wander are lost");
        ResponseEntity<String> actualHandleCustomValidationExceptionResult = globalExceptionHandler
                .handleCustomValidationException(ex);
        verify(ex).getMessage();
        assertEquals("Not all who wander are lost", actualHandleCustomValidationExceptionResult.getBody());
        assertEquals(400, actualHandleCustomValidationExceptionResult.getStatusCodeValue());
        assertTrue(actualHandleCustomValidationExceptionResult.getHeaders().isEmpty());
    }
}