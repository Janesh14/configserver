package com.spotify.authenticationserver.exception;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class InvalidTokenExceptionTest {

    @Test
    void testConstructor() {
        InvalidTokenException actualInvalidTokenException = new InvalidTokenException(
                "Missing Or Invalid Authentication Header");
        assertEquals("Missing Or Invalid Authentication Header", actualInvalidTokenException.getLocalizedMessage());
        assertEquals("Missing Or Invalid Authentication Header", actualInvalidTokenException.getMessage());
        assertNull(actualInvalidTokenException.getCause());
        assertEquals(0, actualInvalidTokenException.getSuppressed().length);
    }
}
