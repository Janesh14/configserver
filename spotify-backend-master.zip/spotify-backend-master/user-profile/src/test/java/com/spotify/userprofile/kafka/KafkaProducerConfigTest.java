package com.spotify.userprofile.kafka;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.test.util.ReflectionTestUtils;

class KafkaProducerConfigTest {

    private KafkaProducerConfig kafkaProducerConfigUnderTest;

    @BeforeEach
    void setUp() {
        kafkaProducerConfigUnderTest = new KafkaProducerConfig();
        ReflectionTestUtils.setField(kafkaProducerConfigUnderTest, "bootstrapAddress", "bootstrapAddress");
    }

    @Test
    void testProducerFactory() {
        // Setup
        // Run the test
        final ProducerFactory<String, Object> result = kafkaProducerConfigUnderTest.producerFactory();

        // Verify the results
    }

    @Test
    void testKafkaTemplate() {
        // Setup
        // Run the test
        final KafkaTemplate<String, Object> result = kafkaProducerConfigUnderTest.kafkaTemplate();

        // Verify the results
    }
}
