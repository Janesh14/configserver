package com.cts.musicapp.model;

import lombok.Data;

@Data
public class ExternalIds {
    private String isrc;
    private String ean;
    private String upc;
}
