package com.cts.wishlist.controller;

import com.cts.wishlist.model.Wishlist;
import com.cts.wishlist.service.WishListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/wishlist/v1")
public class WishListController {
        @Autowired
        private WishListService wishListService;

        @PostMapping("/create")
        public Wishlist saveTrack(@RequestBody Wishlist wishlist){
            return wishListService.saveWishList(wishlist);
        }

        @GetMapping("/search/{id}")
        public Wishlist getTrack(@PathVariable("id") String id){
            return wishListService.getTrack(id);
        }
    @GetMapping("/getAll")
    public ResponseEntity<List<Wishlist>> getAllWishlists() {
        List<Wishlist> wishlists = wishListService.getAllWishlists();
        return new ResponseEntity<>(wishlists, HttpStatus.OK);
    }
        @DeleteMapping("/delete/{id}")
        public void deleteTrack(@PathVariable("id") String id){
             wishListService.deleteTrack(id);
        }
}
