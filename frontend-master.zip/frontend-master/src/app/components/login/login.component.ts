import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginRequest } from '../models/LoginRequest';
import { LoginService } from '../service/login.service';
import { ValidateloginService } from '../service/validatelogin.service';
import { Users } from '../models/Users';



@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  result: any
  msg: boolean = false;
  loginForm: FormGroup

  constructor(private fb: FormBuilder, private router: Router, 
    private loginService: LoginService,
     public validateloginService: ValidateloginService) { 

    this.loginForm = this.fb.group({
      userName: this.fb.control('', Validators.required),
      password: this.fb.control('', Validators.required)
    })
    sessionStorage.setItem('loginStatus','false')

  }
  user : Users = {
    userName : '',
    email : '',
    password : ''
  }

  userRequest : LoginRequest = {
    userName : '',
    password : ''
  }
   

  ngOnInit(): void {
  }
  onSubmit() {
    if (this.loginForm.valid) {
      console.log('userDetails: ', this.loginForm.value);
      console.log(this.userRequest)
      this.loginService.doLogin(this.userRequest).subscribe(
        (data) => {
        console.log(data);
        this.result = Object.values(data);
        sessionStorage.setItem('loginStatus','true')
        sessionStorage.setItem('token',data.response.token);
       
        window.alert('Login Sucessfully');
        
        this.router.navigate(['/search']);
      },
      (error) =>{
        console.log('register To SpotifyApp -> ',error)
          if(error.error.response == 'User with provided creds not found'){
            window.alert('Please Enter Valid UserName and Password');
          }
      }
      );
    } else {
       this.msg = true;
    }
  }

  check(input: string) {
    return (this.loginForm.get(input)?.invalid && this.loginForm.get(input)?.touched)
     ||
     (this.loginForm.get(input)?.invalid && this.msg)
  }

  reg() {
    this. router. navigate(['/reg']);
    
  }
}

