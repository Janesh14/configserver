package com.spotify.userprofile.config;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.config.annotation.ObjectPostProcessor;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.HashMap;

@ContextConfiguration(classes = {SecurityConfig.class})
@ExtendWith(SpringExtension.class)
class SecurityConfigTest {
    @Autowired
    private SecurityConfig securityConfig;

    @Test
    void testFilterChain() throws Exception {
        ObjectPostProcessor objectPostProcessor = new ObjectPostProcessor() {
            @Override
            public Object postProcess(Object object) {
                return null;
            }
        };
        AuthenticationManagerBuilder authenticationBuilder = new AuthenticationManagerBuilder(objectPostProcessor);
        securityConfig.filterChain(new HttpSecurity(objectPostProcessor, authenticationBuilder, new HashMap<>()));
    }
}
