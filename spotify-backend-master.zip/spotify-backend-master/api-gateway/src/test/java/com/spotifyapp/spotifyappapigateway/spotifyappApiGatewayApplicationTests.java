package com.spotifyapp.spotifyappapigateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class spotifyappApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
