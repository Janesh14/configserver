package com.spotify.userprofile.service;

import com.spotify.userprofile.exception.UserNameIsTaken;
import com.spotify.userprofile.model.User;
import com.spotify.userprofile.repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
public class UserServiceImpl implements UserService{

    @Autowired
    private UserRepo userRepo;

    @Override
    @Transactional
    public User registerUser(User user) {
        Optional<User> userFound = userRepo.findUserByUserName(user.getUserName());
        if(userFound.isEmpty()){
            return userRepo.save(user);
        }
        else{
            throw new UserNameIsTaken("Username is taken. Try using different username");
        }
    }

	public UserRepo getUserRepo() {
		return userRepo;
	}

	public void setUserRepo(UserRepo userRepo) {
		this.userRepo = userRepo;
	}
}
