import { Track } from "./Apis"


export interface ApiResponse{
    result : {
        response : string,
        newsCount : number,
        skipped : number
    },
    list : Track
}