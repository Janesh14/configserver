package com.spotify.userprofile.exception;

import org.junit.jupiter.api.BeforeEach;

class CustomValidationExceptionTest {

    private CustomValidationException customValidationExceptionUnderTest;

    @BeforeEach
    void setUp() {
        customValidationExceptionUnderTest = new CustomValidationException("message");
    }
}