import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from '../service/login.service';
import { RegistrationComponent } from './registration.component';

describe('RegistrationComponent', () => {
  let component: RegistrationComponent;
  let fixture: ComponentFixture<RegistrationComponent>;

  beforeEach(() => {
    const formBuilderStub = () => ({
      group: object => ({}),
      control: (string, array) => ({})
    });
    const routerStub = () => ({ navigate: array => ({}) });
    const loginServiceStub = () => ({
      doReg: value => ({ subscribe: f => f({}) })
    });
    TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [RegistrationComponent],
      providers: [
        { provide: FormBuilder, useFactory: formBuilderStub },
        { provide: Router, useFactory: routerStub },
        { provide: LoginService, useFactory: loginServiceStub }
      ]
    });
    fixture = TestBed.createComponent(RegistrationComponent);
    component = fixture.componentInstance;
  });

  it('can load instance', () => {
    expect(component).toBeTruthy();
  });

  it(`msg has default value`, () => {
    expect(component.msg).toEqual(false);
  });

  describe('onSubmit', () => {
    it('makes expected calls', () => {
      const loginServiceStub: LoginService = fixture.debugElement.injector.get(
        LoginService
      );
      spyOn(component, 'login').and.callThrough();
      spyOn(loginServiceStub, 'doReg').and.callThrough();
      component.onSubmit();
      expect(component.login).toHaveBeenCalled();
      expect(loginServiceStub.doReg).toHaveBeenCalled();
    });
  });

  describe('login', () => {
    it('makes expected calls', () => {
      const routerStub: Router = fixture.debugElement.injector.get(Router);
      spyOn(routerStub, 'navigate').and.callThrough();
      component.login();
      expect(routerStub.navigate).toHaveBeenCalled();
    });
  });
});
