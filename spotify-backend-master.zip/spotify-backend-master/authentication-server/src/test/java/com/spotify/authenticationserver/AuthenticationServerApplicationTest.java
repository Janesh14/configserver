package com.spotify.authenticationserver;

import org.junit.jupiter.api.Test;

class AuthenticationServerApplicationTest {

    @Test
    void testMain() {
//        AuthenticationServerApplication.main(new String[]{"The AuthenticationServerApplication has started"});
    }
}
