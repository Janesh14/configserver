package com.spotify.authenticationserver.kafka;

import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class KafkaConsumer {

    @KafkaListener(topics = "userServerTopic")
    public void listen(ConsumerRecord<String, String> record) {
        System.out.println("Received Message: " + record.value());

    }
}