package com.spotify.ConfigServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpotifyConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
