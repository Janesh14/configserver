package com.cts.musicapp.model;

import lombok.Data;

@Data
public class WishList {
    private String id;
    private String name;
//    private String artistName;
}
