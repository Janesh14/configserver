package com.spotify.userprofile.kafka;

import org.apache.kafka.clients.admin.NewTopic;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.kafka.core.KafkaAdmin;
import org.springframework.test.util.ReflectionTestUtils;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class KafkaTopicConfigTest {

    private KafkaTopicConfig kafkaTopicConfigUnderTest;

    @BeforeEach
    void setUp() {
        kafkaTopicConfigUnderTest = new KafkaTopicConfig();
        ReflectionTestUtils.setField(kafkaTopicConfigUnderTest, "bootstrapAddress", "bootstrapAddress");
    }

    @Test
    void testKafkaAdmin() {
        // Setup
        // Run the test
        final KafkaAdmin result = kafkaTopicConfigUnderTest.kafkaAdmin();

        // Verify the results
    }

    @Test
    void testTopic1() {
        NewTopic actualTopic1Result = (new KafkaTopicConfig()).topic1();
        assertEquals("userServerTopic", actualTopic1Result.name());
        assertNull(actualTopic1Result.replicasAssignments());
        assertNull(actualTopic1Result.configs());
    }
}
