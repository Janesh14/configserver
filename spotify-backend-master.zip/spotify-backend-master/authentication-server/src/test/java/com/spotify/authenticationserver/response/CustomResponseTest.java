package com.spotify.authenticationserver.response;

import org.junit.jupiter.api.Test;

class CustomResponseTest {

    @Test
    void testSetResponse() {
        CustomResponse<Object> customResponse = new CustomResponse<>();
        customResponse.setResponse("Not all who wander are lost");
    }
}
