// tracks-result.model.ts
export interface TracksResult {
    href: string;
    items: TrackResult[];
  }
  
// album.model.ts
export interface Album {
    album_type: string;
    total_tracks: number;
    available_markets: string[];
    external_urls: ExternalUrls;
    id: string;
    href: string;
    images: Image[];
    name: string;
    release_date: string;
    release_date_precision: string;
    restrictions: Restrictions;
    type: string;
    uri: string;
    artists: SimpleArtist[];
  }
   
  // album-result.model.ts
  export interface AlbumResult {
    images: Image[];
    name: string;
    artists: SimpleArtistResult[];
  }
   
  // artist.model.ts
  export interface Artist {
    external_urls: ExternalUrls;
    followers: Followers;
    genres: string[];
    href: string;
    id: string;
    images: Image[];
    name: string;
    popularity: number;
    type: string;
    uri: string;
  }
   
  // auth-response.model.ts
  export interface AuthResponse {
    access_token: string;
    token_type: string;
    expires_in: string;
  }
   
  // external-ids.model.ts
  export interface ExternalIds {
    isrc: string;
    ean: string;
    upc: string;
  }
   
  // external-urls.model.ts
  export interface ExternalUrls {
    spotify: string;
  }
   
  // followers.model.ts
  export interface Followers {
    href: string;
    total: number;
  }
   
  // image.model.ts
  export interface Image {
    url: string;
    height: number;
    width: number;
  }
   
  // restrictions.model.ts
  export interface Restrictions {
    reason: string;
  }
   
  // search-response.model.ts
  export interface SearchResponse {
    tracks: Tracks;
  }
   
  // simple-artist.model.ts
  export interface SimpleArtist {
    external_urls: ExternalUrls;
    href: string;
    id: string;
    name: string;
    type: string;
    uri: string;
  }
   
  // simple-artist-result.model.ts
  export interface SimpleArtistResult {
    name: string;
  }
   
  // track.model.ts
  export interface Track {
    album: Album;
    artists: Artist[];
    available_markets: string[];
    disc_number: number;
    duration_ms: number;
    explicit: boolean;
    external_ids: ExternalIds;
    external_urls: ExternalUrls;
    href: string;
    Id: string;
    is_playable: boolean;
    linked_from: object;
    restrictions: Restrictions;
    name: string;
    popularity: string;
    preview_url: string;
    track_number: number;
    type: string;
    uri: string;
    is_local: boolean;
  }
   
  // track-result.model.ts
  export interface TrackResult {
    album: AlbumResult;
    duration_ms: number;
    href: string;
    Id: string;
    name: string;
    preview_url: string;
    type: string;
    uri: string;
  }
   
  // tracks.model.ts
  export interface Tracks {
    href: string;
    limit: number;
    next: string;
    offset: number;
    previous: string;
    total: number;
    items: Track[];
  }
   
  // wishlist.model.ts
  export interface WishList {
    id: string;
    name: string;
    
  }
