import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { LoginRequest } from '../models/LoginRequest';
import { LoginResponse } from '../models/LoginResponse';
import { TracksResult, WishList } from '../models/Apis';
import { Users } from '../models/Users';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
 
  private baseUrl1 = 'http://localhost:8085/musicapp/v1';
  trackName : string = '';  
  limit : string = '';
  constructor(private http: HttpClient) { }


  setTrackName(trackName: string) {
    this.trackName = trackName;
  }
  getTrackName() {
    return this.trackName;
  }
  setLimit(limit: string) {
    this.limit = limit;
  }
  getLimit() {
    return this.limit;
  }
  doLogin(loginRequest : LoginRequest) : Observable<LoginResponse>{
    return this.http.post<LoginResponse>("http://localhost:8092/api/v1.0/auth/login",loginRequest);
  }
  doReg(users: Users) {
    return this.http.post("http://localhost:8081/api/v1.0/user/register", users);
  }
  

  getTracks(trackName: string, limit: string): Observable<TracksResult> {
    const url = `${this.baseUrl1}/search/${trackName}/${limit}`;
    return this.http.get<TracksResult>(url);
  }
  addSongsToWishList(wishList : WishList) : Observable<WishList> {
    return this.http.post<WishList>("http://localhost:8085/musicapp/v1/addtowishlist", wishList )
  }

  getSongsWishListed(): Observable<WishList[]>{
    console.log('Bearer ' + sessionStorage.getItem('token'))
    return this.http.get<WishList[]>("http://localhost:8086/wishlist/v1/getAll", { headers: { Authorization: 'Bearer ' + sessionStorage.getItem('token') } });
  }

  removeFromWishList(id: string) : Observable<string>{
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + sessionStorage.getItem('token')
      }),
      body: id 
    };
    return this.http.delete<string>("http://localhost:8086/wishlist/v1/delete/"+id , httpOptions)
  }
}
