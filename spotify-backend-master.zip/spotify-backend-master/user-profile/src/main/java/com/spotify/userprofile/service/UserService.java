package com.spotify.userprofile.service;

import com.spotify.userprofile.model.User;

public interface UserService {
    User registerUser(User user);
}
