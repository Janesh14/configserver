import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { LoginService } from '../service/login.service';
import { WishList } from '../models/Apis';
import { FormsModule } from '@angular/forms';
import { SearchComponent } from './search.component';

describe('SearchComponent', () => {
  let component: SearchComponent;
  let fixture: ComponentFixture<SearchComponent>;

  beforeEach(() => {
    const loginServiceStub = () => ({
      getTracks: (trackName, limit) => ({ subscribe: f => f({}) }),
      addSongsToWishList: wishList => ({ subscribe: f => f({}) })
    });
    TestBed.configureTestingModule({
      imports: [FormsModule],
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [SearchComponent],
      providers: [{ provide: LoginService, useFactory: loginServiceStub }]
    });
    fixture = TestBed.createComponent(SearchComponent);
    component = fixture.componentInstance;
  });

  it('can load instance', () => {
    expect(component).toBeTruthy();
  });

  it(`messageToCheck has default value`, () => {
    expect(component.messageToCheck).toEqual(
      `Song Already Wishlisted by the User`
    );
  });

  describe('addSongsToWishlist', () => {
    it('makes expected calls', () => {
      const loginServiceStub: LoginService = fixture.debugElement.injector.get(
        LoginService
      );
      const wishListStub: WishList = <any>{};
      spyOn(loginServiceStub, 'addSongsToWishList').and.callThrough();
      component.addSongsToWishlist(wishListStub);
      expect(loginServiceStub.addSongsToWishList).toHaveBeenCalled();
    });
  });

  describe('searchMusic', () => {
    it('makes expected calls', () => {
      const loginServiceStub: LoginService = fixture.debugElement.injector.get(
        LoginService
      );
      spyOn(loginServiceStub, 'getTracks').and.callThrough();
      component.searchMusic();
      expect(loginServiceStub.getTracks).toHaveBeenCalled();
    });
  });
});
