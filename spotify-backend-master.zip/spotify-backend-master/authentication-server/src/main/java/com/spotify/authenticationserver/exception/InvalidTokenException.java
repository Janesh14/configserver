package com.spotify.authenticationserver.exception;

public class InvalidTokenException extends Throwable {
    public InvalidTokenException(String missingOrInvalidAuthenticationHeader) {
        super(missingOrInvalidAuthenticationHeader);
    }
}
