import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from '../service/login.service';


@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  regForm: FormGroup
  msg: boolean = false;
  emailPattern = "^[a-zA-Z0-9_+&*-]+(?:\\." + "[a-zA-Z0-9_+&*-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-z" + "A-Z]{2,7}$";
  constructor(private fb: FormBuilder, private loginService: LoginService, private router: Router) { 
    this.regForm = this.fb.group({
      userName: this.fb.control('',[Validators.required,Validators.pattern("[A-Za-z ]{1,20}"), Validators.minLength(3), Validators.maxLength(20)]),
      email: this.fb.control('',[Validators.required, Validators.pattern(this.emailPattern)]),
      password: this.fb.control('', [Validators.required, Validators.pattern("((?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{6,12})")]),
      })
  }

  ngOnInit(): void {
    }
   
    onSubmit() {
      console.log(this.regForm.value);
      if (this.regForm.valid) {
        this.loginService.doReg(this.regForm.value).subscribe({
          next: (data) => {
            window.alert('Registered Sucessfully');
            console.log(data);
            this.login();
          },
      error: (error) => {
        console.log(error.error);
        alert(error.error);
      }
    });
  } else {
    this.msg = true;
    window.alert('Please fill all required field');
  }
}
  resetBtn() {
    this.regForm.reset();
    this.msg = false;
  }
  check(input: string) {
    return(this.regForm.get(input)?.errors?.['required'] && this.regForm.get(input)?.touched) || (this.regForm.get(input)?.errors?.['required'] && this.msg)
  }

  checkLength(input: string) {
    return (this.regForm.get(input)?.errors?.['minlength'] || this.regForm.get(input)?.errors?.['maxlength']);
  }
  login(){
    this.router.navigate(['/login']);
  }
}

