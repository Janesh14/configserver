package com.cts.musicapp.model;

import lombok.Data;

@Data
public class Followers {
    private String href;
    private Integer total;
}
