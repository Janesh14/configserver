package com.cts.musicapp.model;

import lombok.Data;

@Data
public class SearchResponse {
    private Tracks tracks;
}
