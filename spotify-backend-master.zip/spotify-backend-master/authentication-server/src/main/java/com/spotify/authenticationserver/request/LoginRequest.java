package com.spotify.authenticationserver.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LoginRequest {
    private String userName;
    private String password;

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserName() {
		// TODO Auto-generated method stub
		return userName;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPassword() {

		return password;
	}
}
