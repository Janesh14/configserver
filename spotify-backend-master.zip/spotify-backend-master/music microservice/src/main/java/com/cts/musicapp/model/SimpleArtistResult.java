package com.cts.musicapp.model;

import lombok.Data;

@Data
public class SimpleArtistResult {
    private String name;
}
