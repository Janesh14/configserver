import { Component } from '@angular/core';
import { LoginService } from '../service/login.service';
import { TracksResult, WishList } from '../models/Apis';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent {
  trackName: string = '';
  limit: string = '';
  tracksResult: any; 
  errorMessage: string = '';
  messageToCheck : string  =  'Song Already Wishlisted by the User'
  errorMsgToCheck : string = ''
  result: Object;
 
  constructor(private musicService: LoginService) {}
 
  searchMusic(): void {
    this.musicService.getTracks(this.trackName, this.limit).subscribe(
      (result) => {
        this.tracksResult = result;
        console.log(this.tracksResult)
        this.errorMessage = '';
      },
      (err) => {
        console.log(err);
        this.tracksResult = null;
        this.errorMessage = 'Error fetching tracks.';
      }
    );
  }
  addSongsToWishlist(wishList : WishList){
    this.musicService.addSongsToWishList(wishList).subscribe(
      (res)=>{
        console.log('addSongsToWishList -> ',res)
          window.alert("Article added to your whishlist")
      },
      (error) => {
        console.log('addSongsToWishList',error)
        console.log(error.error)
        this.errorMsgToCheck = error.error;
        if(this.errorMsgToCheck.includes(this.messageToCheck)){
          window.alert("This Songs already added to your wishlist")
        }
      }
    )
  }
 

}