package com.spotify.userprofile.exception;

import org.junit.jupiter.api.BeforeEach;

class UserNameIsTakenTest {

    private UserNameIsTaken userNameIsTakenUnderTest;

    @BeforeEach
    void setUp() {
        userNameIsTakenUnderTest = new UserNameIsTaken("s");
    }
}