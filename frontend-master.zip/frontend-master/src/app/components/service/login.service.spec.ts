import { TestBed } from '@angular/core/testing';
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';
import { LoginRequest } from '../models/LoginRequest';
import { WishList } from '../models/Apis';
import { Users } from '../models/Users';
import { LoginService } from './login.service';

describe('LoginService', () => {
  let service: LoginService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [LoginService]
    });
    service = TestBed.inject(LoginService);
  });

  it('can load instance', () => {
    expect(service).toBeTruthy();
  });

  describe('doLogin', () => {
    it('makes expected calls', () => {
      const httpTestingController = TestBed.inject(HttpTestingController);
      const loginRequestStub: LoginRequest = <any>{};
      service.doLogin(loginRequestStub).subscribe(res => {
       
      });
      const req = httpTestingController.expectOne(
        'http://localhost:8092/api/v1.0/auth/login'
      );
      expect(req.request.method).toEqual('POST');
      req.flush(loginRequestStub);
      httpTestingController.verify();
    });
  });

  describe('doReg', () => {
    it('makes expected calls', () => {
      const httpTestingController = TestBed.inject(HttpTestingController);
      const usersStub: Users = <any>{};
      service.doReg(usersStub).subscribe(res => {
        expect(res).toEqual(usersStub);
      });
      const req = httpTestingController.expectOne(
        'http://localhost:8092/api/v1.0/auth/login'
      );
      expect(req.request.method).toEqual('POST');
      req.flush(usersStub);
      httpTestingController.verify();
    });
  });

  describe('addSongsToWishList', () => {
    it('makes expected calls', () => {
      const httpTestingController = TestBed.inject(HttpTestingController);
      const wishListStub: WishList = <any>{};
      service.addSongsToWishList(wishListStub).subscribe(res => {
        expect(res).toEqual(wishListStub);
      });
      const req = httpTestingController.expectOne(
        'http://localhost:8092/api/v1.0/auth/login'
      );
      expect(req.request.method).toEqual('POST');
      req.flush(wishListStub);
      httpTestingController.verify();
    });
  });

  describe('getSongsWishListed', () => {
    it('makes expected calls', () => {
      const httpTestingController = TestBed.inject(HttpTestingController);
      service.getSongsWishListed().subscribe(res => {
        expect(res).toEqual([]);
      });
      const req = httpTestingController.expectOne('HTTP_ROUTE_GOES_HERE');
      expect(req.request.method).toEqual('GET');
      req.flush([]);
      httpTestingController.verify();
    });
  });
});
