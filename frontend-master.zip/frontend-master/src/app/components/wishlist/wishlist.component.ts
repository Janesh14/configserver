import { Component, OnInit } from '@angular/core';
import { WishList } from '../models/Apis';
import { LoginService } from '../service/login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-wishlist',
  templateUrl: './wishlist.component.html',
  styleUrls: ['./wishlist.component.css']
})
export class WishlistComponent implements OnInit {
  wishlists: WishList[];

  constructor(private wishlistService: LoginService, private router: Router) {}

  ngOnInit(): void {
    this.getAllWishlists();
  }

  getAllWishlists(): void {
    this.wishlistService.getSongsWishListed().subscribe(
      (data) => {
        this.wishlists = data;
        console.log(this.wishlists)
      },
      (error) => {
        console.error('Error fetching wishlists:', error);
      }
    );
  }

  deleteTrack(id: string): void {
    this.wishlistService.removeFromWishList(id).subscribe(
      () => {
        console.log('Track deleted successfully');
        window.alert('deleted Successfully')
      
        window.location.reload();
      },
      (error) => {
        console.error('Error deleting track:', error);
      }
    );
  }
  search(){
    this.router.navigate(['/search']);
  }
}