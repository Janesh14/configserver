package com.spotify.authenticationserver.request;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class LoginRequestTest {

    @Test
    void testSetPassword() {
        LoginRequest loginRequest = new LoginRequest("USER", "987654321");
        loginRequest.setPassword("987654321");
        loginRequest.setUserName("USER");
        String actualPassword = loginRequest.getPassword();
        assertEquals("987654321", actualPassword);
        assertEquals("USER", loginRequest.getUserName());
    }
}
