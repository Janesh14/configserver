import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { LoginService } from '../service/login.service';
import { Router } from '@angular/router';
import { WishlistComponent } from './wishlist.component';

describe('WishlistComponent', () => {
  let component: WishlistComponent;
  let fixture: ComponentFixture<WishlistComponent>;

  beforeEach(() => {
    const loginServiceStub = () => ({
      getSongsWishListed: () => ({ subscribe: f => f({}) }),
      removeFromWishList: id => ({ subscribe: f => f({}) })
    });
    const routerStub = () => ({ navigate: array => ({}) });
    TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [WishlistComponent],
      providers: [
        { provide: LoginService, useFactory: loginServiceStub },
        { provide: Router, useFactory: routerStub }
      ]
    });
    fixture = TestBed.createComponent(WishlistComponent);
    component = fixture.componentInstance;
  });

  it('can load instance', () => {
    expect(component).toBeTruthy();
  });

  describe('ngOnInit', () => {
    it('makes expected calls', () => {
      spyOn(component, 'getAllWishlists').and.callThrough();
      component.ngOnInit();
      expect(component.getAllWishlists).toHaveBeenCalled();
    });
  });

  describe('getAllWishlists', () => {
    it('makes expected calls', () => {
      const loginServiceStub: LoginService = fixture.debugElement.injector.get(
        LoginService
      );
      spyOn(loginServiceStub, 'getSongsWishListed').and.callThrough();
      component.getAllWishlists();
      expect(loginServiceStub.getSongsWishListed).toHaveBeenCalled();
    });
  });

  describe('search', () => {
    it('makes expected calls', () => {
      const routerStub: Router = fixture.debugElement.injector.get(Router);
      spyOn(routerStub, 'navigate').and.callThrough();
      component.search();
      expect(routerStub.navigate).toHaveBeenCalled();
    });
  });
});
