package com.spotify.authenticationserver.service;

import com.spotify.authenticationserver.model.User;
import com.spotify.authenticationserver.repository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class UserServiceImpl implements UserService{

    @Autowired
    private UserRepository userRepository;

    public boolean validateUserService(String userName, String password) {
        System.out.println("The call entered validateUserService() and should check for validation");
        User user = userRepository.validateUser(userName, password);
        if (user != null) {
        	System.out.println("User found");
            return true;
        }
        else {
        	System.out.println("User not found");
            return false;
        }
    }
}
