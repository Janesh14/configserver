package com.spotify.authenticationserver.exception;


import com.spotify.authenticationserver.response.CustomResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

@ContextConfiguration(classes = {GlobalExceptionHandler.class})
@ExtendWith(SpringExtension.class)
class GlobalExceptionHandlerTest {
    @Autowired
    private GlobalExceptionHandler globalExceptionHandler;

    @Test
    void testInCaseOfUserNotFound() {
        ResponseEntity<CustomResponse<String>> actualInCaseOfUserNotFoundResult = globalExceptionHandler
                .inCaseOfUserNotFound(new UserNotFoundException("foo"));
        assertEquals(404, actualInCaseOfUserNotFoundResult.getStatusCodeValue());
        assertTrue(actualInCaseOfUserNotFoundResult.hasBody());
        assertTrue(actualInCaseOfUserNotFoundResult.getHeaders().isEmpty());
    }


    @Test
    void testInCaseOfUserNotFound2() {
        UserNotFoundException e = mock(UserNotFoundException.class);
        when(e.getMessage()).thenReturn("Not all who wander are lost");
        ResponseEntity<CustomResponse<String>> actualInCaseOfUserNotFoundResult = globalExceptionHandler
                .inCaseOfUserNotFound(e);
        verify(e).getMessage();
        assertEquals(404, actualInCaseOfUserNotFoundResult.getStatusCodeValue());
        assertTrue(actualInCaseOfUserNotFoundResult.hasBody());
        assertTrue(actualInCaseOfUserNotFoundResult.getHeaders().isEmpty());
    }

    @Test
    void testInCaseInvalidTokenException() {
        ResponseEntity<CustomResponse<String>> actualInCaseInvalidTokenExceptionResult = globalExceptionHandler
                .inCaseInvalidTokenException(new InvalidTokenException("Missing Or Invalid Authentication Header"));
        assertEquals(400, actualInCaseInvalidTokenExceptionResult.getStatusCodeValue());
        assertTrue(actualInCaseInvalidTokenExceptionResult.hasBody());
        assertTrue(actualInCaseInvalidTokenExceptionResult.getHeaders().isEmpty());
    }

    @Test
    void testInCaseInvalidTokenException2() {
        InvalidTokenException e = mock(InvalidTokenException.class);
        when(e.getMessage()).thenReturn("Not all who wander are lost");
        ResponseEntity<CustomResponse<String>> actualInCaseInvalidTokenExceptionResult = globalExceptionHandler
                .inCaseInvalidTokenException(e);
        verify(e).getMessage();
        assertEquals(400, actualInCaseInvalidTokenExceptionResult.getStatusCodeValue());
        assertTrue(actualInCaseInvalidTokenExceptionResult.hasBody());
        assertTrue(actualInCaseInvalidTokenExceptionResult.getHeaders().isEmpty());
    }
}
