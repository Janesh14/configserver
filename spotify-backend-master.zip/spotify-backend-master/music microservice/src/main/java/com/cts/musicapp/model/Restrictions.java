package com.cts.musicapp.model;

import lombok.Data;

@Data
public class Restrictions {
    private String reason;
}
